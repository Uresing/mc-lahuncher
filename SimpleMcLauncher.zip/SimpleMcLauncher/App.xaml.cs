using System.Windows;

namespace SimpleMcLauncher;

public partial class App : Application
{
}
