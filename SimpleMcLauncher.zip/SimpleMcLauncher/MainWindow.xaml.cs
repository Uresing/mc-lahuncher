using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using CmlLib.Core;
using CmlLib.Core.Auth;
using CmlLib.Core.Installers;
using CmlLib.Core.ProcessBuilder;
using CmlLib.Core.Version;

namespace SimpleMcLauncher;

public partial class MainWindow : Window
{
    private readonly MinecraftLauncher _launcher;
    private readonly MinecraftPath _path;
    private readonly string _configFilePath;

    public MainWindow()
    {
        InitializeComponent();

        _path = new MinecraftPath(); // Varsayılan %appdata%\.minecraft
        _launcher = new MinecraftLauncher(_path);

        _configFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "launcher_config.json");

        // Eventleri bağla
        _launcher.FileProgressChanged += Launcher_FileProgressChanged;
        _launcher.ByteProgressChanged += (sender, e) =>
        {
            Dispatcher.Invoke(() =>
            {
                if (e.TotalBytes > 0)
                {
                    var percent = (double)e.ProgressedBytes / e.TotalBytes * 100.0;
                    DownloadProgressBar.Value = percent;
                }
            });
        };

        Loaded += MainWindow_Loaded;
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        LoadSettings();
        await LoadMinecraftVersionsAsync();
    }

    private async Task LoadMinecraftVersionsAsync()
    {
        try
        {
            StatusTextBlock.Text = "Sürümler listeleniyor...";
            PlayButton.IsEnabled = false;

            var versions = await _launcher.GetAllVersionsAsync();

            VersionComboBox.Items.Clear();

            // Sadece release (kararlı vanilla) sürümlerini filtrele
            var releaseVersions = versions
                .Where(v => v.Type == "release")
                .ToList();

            foreach (var version in releaseVersions)
            {
                VersionComboBox.Items.Add(version.Name);
            }

            if (VersionComboBox.Items.Count > 0)
            {
                VersionComboBox.SelectedIndex = 0; // En güncel kararlı sürüm
            }

            StatusTextBlock.Text = "Hazır!";
            PlayButton.IsEnabled = true;
        }
        catch (Exception ex)
        {
            StatusTextBlock.Text = "Sürüm listesi alınamadı: " + ex.Message;
            PlayButton.IsEnabled = true;
        }
    }

    private void Launcher_FileProgressChanged(object? sender, InstallerProgressChangedEventArgs e)
    {
        Dispatcher.Invoke(() =>
        {
            if (e.TotalTasks > 0)
            {
                var percent = (double)e.ProgressedTasks / e.TotalTasks * 100.0;
                DownloadProgressBar.Value = percent;
                StatusTextBlock.Text = $"İndiriliyor ({e.ProgressedTasks}/{e.TotalTasks}): {e.Name}";
            }
        });
    }



    private async void PlayButton_Click(object sender, RoutedEventArgs e)
    {
        var username = UsernameBox.Text.Trim();
        if (string.IsNullOrWhiteSpace(username))
        {
            MessageBox.Show("Lütfen bir oyuncu adı (nickname) girin!", "Uyarı", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var selectedVersion = VersionComboBox.SelectedItem as string;
        if (string.IsNullOrEmpty(selectedVersion))
        {
            MessageBox.Show("Lütfen bir sürüm seçin!", "Uyarı", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        int ramMb = 4096;
        if (RamComboBox.SelectedItem is ComboBoxItem item && int.TryParse(item.Tag?.ToString(), out int parsedRam))
        {
            ramMb = parsedRam;
        }

        SaveSettings();

        PlayButton.IsEnabled = false;
        DownloadProgressBar.Value = 0;
        StatusTextBlock.Text = "Oyun hazırlanıyor, dosyalar kontrol ediliyor...";

        try
        {
            // Kullanıcı adına göre oturum oluşturma (Vanilla / Offline Session)
            var session = MSession.CreateOfflineSession(username);

            var launchOptions = new MLaunchOption
            {
                Session = session,
                MaximumRamMb = ramMb
            };

            StatusTextBlock.Text = $"{selectedVersion} sürümü kontrol ediliyor ve kütüphaneler indiriliyor...";

            // Oyunu başlatacak süreci oluştur
            var process = await _launcher.CreateProcessAsync(selectedVersion, launchOptions);

            StatusTextBlock.Text = "Minecraft başlatılıyor...";
            DownloadProgressBar.Value = 100;

            process.Start();

            StatusTextBlock.Text = "Minecraft açıldı! İyi oyunlar.";

            // İsteğe bağlı: Oyun açılınca arayüzü küçült veya açık bırak
            WindowState = WindowState.Minimized;
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Oyun başlatılamadı:\n{ex.Message}", "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
            StatusTextBlock.Text = "Hata oluştu.";
        }
        finally
        {
            PlayButton.IsEnabled = true;
        }
    }

    private void SaveSettings()
    {
        try
        {
            var config = new LauncherConfig
            {
                Email = EmailBox.Text,
                Username = UsernameBox.Text,
                Password = PasswordBox.Password,
                SelectedRamIndex = RamComboBox.SelectedIndex
            };

            var json = JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_configFilePath, json);
        }
        catch { }
    }

    private void LoadSettings()
    {
        try
        {
            if (File.Exists(_configFilePath))
            {
                var json = File.ReadAllText(_configFilePath);
                var config = JsonSerializer.Deserialize<LauncherConfig>(json);
                if (config != null)
                {
                    if (!string.IsNullOrEmpty(config.Email)) EmailBox.Text = config.Email;
                    if (!string.IsNullOrEmpty(config.Username)) UsernameBox.Text = config.Username;
                    if (!string.IsNullOrEmpty(config.Password)) PasswordBox.Password = config.Password;
                    if (config.SelectedRamIndex >= 0 && config.SelectedRamIndex < RamComboBox.Items.Count)
                    {
                        RamComboBox.SelectedIndex = config.SelectedRamIndex;
                    }
                }
            }
        }
        catch { }
    }

    public class LauncherConfig
    {
        public string Email { get; set; } = string.Empty;
        public string Username { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public int SelectedRamIndex { get; set; } = 1;
    }
}
